import java.util.Arrays;

public class MainClass {
	public static void main(String[] args) {
				

		/*
			int num1, num2, num3, num4, num5;
			
			num1 = 11;
			num2 = 22;
			num3 = 33;			
			
			Array : 배열. 같은 자료형 변수들의 묶음. <- 변수들
			 		목적 -> 변수관리. 관리는 index number 구분 
			 		
			형식 :
			 		자료형 배열변수명[]	= new 자료형[배열의 총갯수];
			 		배열변수명[index number]
			 		
			 		int arrName[] = new int[5]; -> 정수형 변수 5개 선언
			 						동적(dynamic)할당	정적(static)
			 		arrName[0] = 11;
			 		arrName[1] = 22;
			 		arrName[2] = 33;
			 		arrName[3] = 44;
			 		arrName[4] = 55;		
		*/
		
	//	int array[] = new int[5];
	//	int []array = new int[5];
		int[] array = new int[5];	// 0 ~ 4
		
		array[0] = 11;
		array[1] = 22;
		array[2] = 33;
		array[3] = 44;
		array[4] = 55;
		
		System.out.println(array);	// 36aa7bc2 <- Heap 영역의 주소
		
		System.out.println(array.length); // 배열의 길이
		
		int num1, num2;
		num1 = 333;
		
		System.out.println(num1);
		System.out.println(array[0]);
		
		
		
		System.out.println(array[2]);		
		System.out.println(Arrays.toString(array));
		
		// 선언 & 초기화
		int number = 0;
		number = 1;	// 값의 갱신
		
		// 배열 선언 & 초기화
		int Array[] = { 111, 222, 333, 444, 555 };	
					//   0    1    2    3    4
		System.out.println(Array[1]);
		
		
		char chArr[] = { 'h', 'e', 'l', 'l', 'o' };
		
		System.out.println(chArr.length);
		System.out.println(Arrays.toString(chArr));
		
		System.out.println(chArr);
		
		char c = 'A';
		System.out.println(c);
		System.out.println((int)c); // <- 65 == ASCII
		
		
	//	String strArr[] = 
		
		/*
		
		자료형 배열변수명[] = new 자료형[배열의 총개수];
		자료형 배열변수명[] = { };

		*/
		
		// int Arr[] = { 1, 2, 3, 4, 5 };
				
		//int Arr[];		
		//Arr = new int[7];
		
		
	}
}





